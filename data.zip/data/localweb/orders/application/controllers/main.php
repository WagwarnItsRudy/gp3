<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {
	 
	 function __construct()
	{
		parent::__construct();	 
		$this->load->database();
		$this->load->helper('url');
		$this->load->library('grocery_CRUD');
		$this->load->library('table');
	}
	
	public function index()
	{	
		$this->load->view('header');
		$this->load->view('home');
	}
	
	public function booking()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		//table name exact from database
		$crud->set_table('booking');
		
		//give focus on name used for operations e.g. Add Order, Delete Order
		$crud->set_subject('Booking');
		
		//the columns function lists attributes you see on frontend view of the table
		$crud->columns('bookingID', 'memberID', 'performanceID', 'seats');
	
		//the fields function lists attributes to see on add/edit forms.
		//Note no inclusion of invoiceNo as this is auto-incrementing
		$crud->fields('bookingID', 'memberID', 'performanceID', 'seats');
		
		//set the foreign keys to appear as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('memberID','members','memberID');
		
		$crud->set_relation('performanceID','performance','performanceID');
		
		//many-to-many relationship with link table see grocery crud website: www.grocerycrud.com/examples/set_a_relation_n_n
		//('give a new name to related column for list in fields here', 'join table', 'other parent table', 'this fk in join table', 'other fk in join table', 'other parent table's viewable column to see in field')
		//$crud->set_relation_n_n('items', 'order_items', 'items', 'invoice_no', 'item_id', 'itemDesc');
		
		//form validation (could match database columns set to "not null")
		$crud->required_fields('bookingID', 'memberNo', 'performanceID', 'seats');
		
		//change column heading name for readability ('columm name', 'name to display in frontend column header')
		$crud->display_as('bookingID', 'Booking ID');
		$crud->display_as('memberID', 'Member ID');
		$crud->display_as('performanceID', 'Performance ID');
		$crud->display_as('seats', 'Seats');
		
		$output = $crud->render();
		$this->orders_output($output);
	}
	
	function orders_output($output = null)
	{
		//this function links up to corresponding page in the views folder to display content for this table
		$this->load->view('orders_view.php', $output);
	}

	public function film()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		$crud->set_table('film');
		$crud->set_subject('Film');
		$crud->fields('filmID', 'filmName', 'director', 'dateofrelease');
		$crud->required_fields('filmID', 'filmName', 'director', 'dateofrelease');
		$crud->display_as('filmID', 'Film ID');
		$crud->display_as('filmName', 'Film Name');
		$crud->display_as('director', 'Director');
		$crud->display_as('dateofrelease', 'Date of Release');
		
		$output = $crud->render();
		$this->items_output($output);
	}
	
	function items_output($output = null)
	{
		$this->load->view('items_view.php', $output);
	}
	public function members()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('members');
		$crud->set_subject('Members');
		$crud->fields('memberID','Title', 'memberFirstName', 'memberLastName', 'memberStatus', 'dateJoined');
		$crud->required_fields('memberID','Title', 'memberName', 'memberStatus', 'dateJoined');
		$crud->display_as('memberID', 'Member ID');
		$crud->display_as('Title', 'Title');
		$crud->display_as('memberFirstName', 'First Name');
		$crud->display_as('memberLastName', 'Last Name');
		$crud->display_as('memberStatus', 'Status');
		$crud->display_as('dateJoined', 'Date Joined');

		
		$output = $crud->render();
		$this->cust_output($output);
	}
	
	function cust_output($output = null)
	{
		$this->load->view('cust_view.php', $output);
	}
	
	public function cinema()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('cinema');
		$crud->set_subject('Cinema');
		$crud->fields('cinemaID', 'cinemaName', 'location', 'address', 'cinemaManager');
		//have multiple columns show in one FK column by concatenation:  www.grocerycrud.com/forums/topic/479-concatenate-two-or-more-fields-into-one-field/
		$crud->required_fields('cinemaID', 'cinemaName', 'location', 'address', 'cinemaManager');
		$crud->display_as('cinemaID', 'Cinema ID');
		$crud->display_as('cinmeaName', 'Cinema Name');
		$crud->display_as('location', 'Location');
		$crud->display_as('address', 'Address');
		$crud->display_as('cinemaManager', 'Manager');
		
		$output = $crud->render();
		$this->orderline_output($output);
	}
	
	function orderline_output($output = null)
	{
		$this->load->view('orderline_view.php', $output);
	}
		public function performance()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		
		//table name exact from database
		$crud->set_table('performance');
		
		//give focus on name used for operations e.g. Add Order, Delete Order
		$crud->set_subject('Performance');
		
		//the columns function lists attributes you see on frontend view of the table
		$crud->columns('performanceID', 'filmID', 'screenNo', 'performDate');
	
		//the fields function lists attributes to see on add/edit forms.
		//Note no inclusion of invoiceNo as this is auto-incrementing
		$crud->fields('performanceID', 'filmID', 'screenNo', 'performDate');
		
		//set the foreign keys to appear as drop-down menus
		// ('this fk column','referencing table', 'column in referencing table')
		$crud->set_relation('filmID','film','filmID');
		
		$crud->set_relation('screenNo','screen','screenNo');
		
		//many-to-many relationship with link table see grocery crud website: www.grocerycrud.com/examples/set_a_relation_n_n
		//('give a new name to related column for list in fields here', 'join table', 'other parent table', 'this fk in join table', 'other fk in join table', 'other parent table's viewable column to see in field')
		//$crud->set_relation_n_n('items', 'order_items', 'items', 'invoice_no', 'item_id', 'itemDesc');
		
		//form validation (could match database columns set to "not null")
		$crud->required_fields('performanceID', 'filmID', 'screenNo', 'performDate');
		
		//change column heading name for readability ('columm name', 'name to display in frontend column header')
		$crud->display_as('performanceID', 'Performance ID');
		$crud->display_as('filmID', 'Film ID');
		$crud->display_as('screenNo', 'Screen Number');
		$crud->display_as('performDate', 'Performance Date');


		
		$output = $crud->render();
		$this->performance_output($output);
	}
	
		function performance_output($output = null)
	{
		$this->load->view('performance_view.php', $output);
	}
	public function screen()
	{	
		$this->load->view('header');
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('screen');
		$crud->set_subject('Screen');
		$crud->fields('cinemaID', 'screenNo', 'seats', 'seatPrice');
		$crud->set_relation('cinemaID','cinema','cinemaID');
		//have multiple columns show in one FK column by concatenation:  www.grocerycrud.com/forums/topic/479-concatenate-two-or-more-fields-into-one-field/
		$crud->required_fields('screenNo', 'cinemaID', 'seats', 'seatPrice');
		$crud->display_as('cinemaID', 'Cinema ID');
		$crud->display_as('screenNo', 'Screen Number');
		$crud->display_as('seats', 'Seats');
		$crud->display_as('seatPrice', 'Seat Price');
		
		$output = $crud->render();
		$this->screen_output($output);
	}
	
	function screen_output($output = null)
	{
		$this->load->view('screen_view.php', $output);
	}

	
	public function querynav()
	{	
		$this->load->view('header');
		$this->load->view('querynav_view');
	}
		
	public function query1()
	{	
		$this->load->view('header');
		$this->load->view('query1_view');
	}
	
	public function query2()
	{	
		$this->load->view('header');
		$this->load->view('query2_view');
	}
	
	public function blank()
	{	
		$this->load->view('header');
		$this->load->view('blank_view');
	}
}
?>