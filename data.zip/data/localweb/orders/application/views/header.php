<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
a:link {
	text-decoration: none;
  
}

a:visited {
	text-decoration: none;
 
}

a:hover {
	text-decoration: none;
}

a:active {
	text-decoration: none;

}
ul {
	width:100%;
	list-style-type: none;
	margin: 2px;
	padding: 0;
	overflow: hidden;
	background-color: #00628B;
	color: white;
	border: 1px solid;
}

li {
	float: left;

}

li a {
	display: block;
	color: white;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
	font-family:Arial;
}

li a:hover {
	background-color: white;
	color: #00628B;
	font-family:Arial;
  
  
}
	
	body{
			background-color: #C4DFE6;
			
			
		}
		h1 { text-align: center; 	font-family: Calibri; }
		p.p-centre { text-align: center; font-family: Arial; }
		#cogs { display: block; padding-top: 20px; margin-left: auto; margin-right: auto; }		
		
		.paragraph{
		display: block;
		line-height: 1.5;
		margin-left: auto;
		margin-right:auto;
		width:80%;
		text-align:justify;
		font-size: 25px;
		font-family: Arial;
		padding: 20px;
		border: 7px solid grey;
				
		}
		
	</style>
</head>
<body>
	<div>
		<ul id="nav">
		<li><a href='<?php echo site_url('')?>'>Home</a></li>
		<li><a href='<?php echo site_url('main/booking')?>'>Booking</a></li>
		<li><a href='<?php echo site_url('main/film')?>'>Film</a></li>
		<li><a href='<?php echo site_url('main/members')?>'>Members</a></li>
		<li><a href='<?php echo site_url('main/cinema')?>'>Cinema</a></li>
		<li><a href='<?php echo site_url('main/performance')?>'>Performance</a></li>
		<li><a href='<?php echo site_url('main/screen')?>'>Screens</a></li>
		<li><a href='<?php echo site_url('main/blank')?>'>Blank Page</a></li>
		<li><a href='<?php echo site_url('main/querynav')?>'>Queries</a></li>
			
		</ul>
	</div>
</body>
</html>
